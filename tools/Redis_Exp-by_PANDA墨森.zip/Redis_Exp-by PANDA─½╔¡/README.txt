Redis_Exp，为了方便自身并简化繁琐操作的redis未授权访问利用脚本
采用python3开发，作者：PANDA墨森

Usage：python3 Redis_Exp.py -h

支持三种利用方式：
1、webshell(绝对路径写shell)
2、ssh-key(私钥登陆ssh)
3、crontab(计划任务反弹shell)

程序会自动检测未授权漏洞

注意根据实际情况修改配置文件：conf.py