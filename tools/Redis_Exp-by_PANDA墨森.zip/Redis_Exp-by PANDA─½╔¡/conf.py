#!/usr/bin/python
# coding=utf-8
''''
*********************************
配置文件：conf.py  By PANDA墨森
根据实际情况修改配置文件即可
*********************************
'''


# 目标网站绝对路径
PATH = '/var/www/html'

# your vps IP
VPS_IP = '192.168.136.129'

# your vps listen port
VPS_PORT = 6666

# your ssh私钥文件的路径
SSH_KEY = 'key.txt'