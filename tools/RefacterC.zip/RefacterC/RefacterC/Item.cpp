#include "stdafx.h"
#include "Item.h"


Item::Item()
	: Object()
{
}


Item::~Item()
{
}
