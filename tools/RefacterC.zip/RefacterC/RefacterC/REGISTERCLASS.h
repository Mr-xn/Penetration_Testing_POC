#pragma once



  
#define REGISTERCLASS(className) \
class className##Helper { \
public: \
    className##Helper() \
    { \
        ClassFactory::instance()->RegisterItem(#className, className##Helper::CreatObjFunc); \
    } \
    static void* CreatObjFunc() \
    { \
        return new className; \
    } \
}; \
className##Helper className##helper;
