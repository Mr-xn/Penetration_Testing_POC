#pragma once


class Object
{
public:
	Object();
	virtual ~Object();

	const string& GetClassName() const { return className; }

protected:
	string className;
};

